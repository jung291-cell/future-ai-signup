from flask import Flask, request, render_template
import csv

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['POST'])
def signup():
    email = request.form['email']
    if email:
        with open('subscribers.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([email])
    return render_template('thank_you.html')

if __name__ == '__main__':
    app.run(debug=True)
